/* Ejercicio 1 */

/* Apartado 1.1 */

let cadena = " mundo";
console.log("Hola" + cadena);

/* Apartado 1.2 */

let numero = 19;
console.log(numero);

/* Apartado 1.3 */

let booleano = true;
console.log(booleano);

/* Apartado 1.4 */

let nulo = null;
let indefinido = undefined;

console.log(nulo, indefinido);

/* Apartado 1.5 */

const articulo = {
    nombre: "Lampara",
    precio: 30,
    categoría: "Media"
};

console.log(articulo);

/* Apartado 1.6 */

const ciudades = ["Madrid","Barcelona","Sevilla","Jerez de la Frontera"];

console.log(ciudades);

/* Apartado 1.7 */

let colorFav = "Verde";
console.log(colorFav);
colorFav = "Rojo";
console.log(colorFav);

/* Apartado 1.8 */

let var1;
let var2 = null;

console.log(var1, var2);

/* Apartado 1.9 */

let cadena1 = "Fuera de la función";

function miFuncion() {
    let cadena2 = "Dentro de la función";
    
    // Llamamos las variables dentro de la función por consola
    console.log(cadena1);
    console.log(cadena2);
}

miFuncion();

// Llamamos las variables fuera de la función por consola
console.log(cadena1);
// console.log(cadena2); No funciona

/* Apartado 1.10 */

let numero1 = 19;
console.log(numero1);

/* No funciona
let 1numero = 20;
console.log(1numero);
*/

/* Apartado 1.11 */

let numero2 = 20;
let numero3 = 5;

let suma = numero2 + numero3;
let resta = numero2 - numero3;
let multiplicacion = numero2 * numero3;
let division = numero2 / numero3;
let resto = numero2 % numero3;

numero2++
let incremento = numero2;

numero3--
let decremento = numero3;

console.log(suma, resta, multiplicacion, division, resto, incremento, decremento);

/* Apartado 1.12 */

let cadenaLarga = "Hola muy buenas\n"
                + "\tEncantado";

console.log(cadenaLarga);

/* Ejercicio 2 */

/* Apartado 2.1 */

let numero4 = 0;

if (numero4 > 0) {
    console.log("El número es positivo.");
} else if (numero4 < 0) {
    console.log("El número es negativo.");
} else {
    console.log("El número es cero.");
}

/* Apartado 2.2 */

let edad = 34;

if (edad < 18) {
    console.log("Eres menor de edad.");
} else if (edad >= 18 && edad < 65) {
    console.log("Eres un adulto.");
} else {
    console.log("Eres anciano.");
}

/* Apartado 2.3 */

for (let i = 0; i < 5; i++) {
    console.log(i);
}

/* Apartado 2.4 */

let contador = 0;

while (contador < 5) {
    console.log(contador);
    contador++;
}

/* Apartado 2.5 */

let x = 0;

do {
    console.log(x);
    x++;
} while (x < 5);

/* Apartado 2.6 */

for (let i = 0; i < 5; i++) {
    if (i === 3) {
        break;
    }
    console.log(i);
}

/* Apartado 2.7 */

for (let j = 0; j < 5; j++) {
    if (j === 2) {
        continue;
    }
    console.log(j);
}

/* Apartado 2.8 */

let numeroMes = prompt("Ingresa un número del 1 al 12:");

switch (parseInt(numeroMes)) {
    case 1: console.log("Enero"); break;
    case 2: console.log("Febrero"); break;
    case 3: console.log("Marzo"); break;
    case 4: console.log("Abril"); break;
    case 5: console.log("Mayo"); break;
    case 6: console.log("Junio"); break;
    case 7: console.log("Julio"); break;
    case 8: console.log("Agosto"); break;
    case 9: console.log("Septiembre"); break;
    case 10: console.log("Octubre"); break;
    case 11: console.log("Noviembre"); break;
    case 12: console.log("Diciembre"); break;
    default: console.log("Número inválido.");
}

/* Ejercicio 3 */

/* Apartado 3.1 */

function calcularArea(radio) {
    return Math.PI * Math.pow(radio, 2);
}

function calcularPerimetro(radio) {
    return 2 * Math.PI * radio;
}

let radio = 3;
console.log("Área del círculo:", calcularArea(radio));
console.log("Perímetro del círculo:", calcularPerimetro(radio));

/* Apartado 3.2 */

let base = 2;
let exponente = 2;

function calcularPotencia(base, exponente) {
    let potencia = base ** exponente;
    return potencia;
}

console.log("Resultado:", calcularPotencia(base, exponente)); 

/* Ejercicio 4 */

/* Apartado 4.1 */

function findLargestNumber(arr) {
    let max = arr[0];
    for (let i = 1; i < arr.length; i++) {
        if (arr[i] > max) {
            max = arr[i];
        }
    }
    return max;
}

function funcionPrincipal() {
    let cantidad = parseInt(prompt("¿Cuántos números deseas ingresar?"));
    let numeros = [];

    for (let i = 0; i < cantidad; i++) {
        let numero = parseFloat(prompt("Introduce el número " + (i+1)+ " :"));
        numeros.push(numero);
    }

    let numeroMasGrande = findLargestNumber(numeros);
    console.log("El número más grande es: " + numeroMasGrande);
}

funcionPrincipal();

/* Ejercicio 5 */

// 1. Imprimir los números del 20 al 30 en la consola
console.log("Números del 20 al 30:");
for (let i = 20; i <= 30; i++) {
    console.log(i);
}

// 2. Imprimir los números pares del 30 al 50 en la consola
console.log("Números pares del 30 al 50:");
for (let i = 30; i <= 50; i++) {
    if (i % 2 === 0) {
        console.log(i);
    }
}

// 3. Calcular la suma de los primeros 50 números naturales
let suma2 = 0;
for (let i = 1; i <= 50; i++) {
    suma2 += i;
}
console.log("Suma de los primeros 50 números naturales: " + suma2);

// 4. Imprimir la tabla de multiplicar del 8
console.log("Tabla de multiplicar del 8:");
for (let i = 1; i <= 10; i++) {
    console.log("8 x " + i + " = " + (8 * i));
}

// 5. Imprimir los elementos de un array
let array = [2, 5, 8, 12, 16, 23];
console.log("Elementos del array:");
for (let i = 0; i < array.length; i++) {
    console.log(array[i]);
}

// 6. Imprimir un patrón de asteriscos en forma de triángulo, con altura 9
let altura = 9;
for (let i = 1; i <= altura; i++) {
    let fila = "";
    for (let j = 1; j <= i; j++) {
        fila += "*";
    }
    console.log(fila);
}

// 7. Calcular la suma de los números pares del 1 al 50
let sumaPares = 0;
for (let i = 1; i <= 50; i++) {
    if (i % 2 === 0) {
        sumaPares += i;
    }
}
console.log("Suma de los números pares del 1 al 50: " + sumaPares);

// 8. Imprimir los números del 30 al 20 en orden descendente
console.log("Números del 30 al 20 en orden descendente:");
for (let i = 30; i >= 20; i--) {
    console.log(i);
}

// 9. Calcular el promedio de un array de números
let numeros = [4, 8, 15, 16, 23, 42];
let sumaArray = 0;
for (let i = 0; i < numeros.length; i++) {
    sumaArray += numeros[i];
}
let promedio = sumaArray / numeros.length;
console.log("Promedio del array: " + promedio);